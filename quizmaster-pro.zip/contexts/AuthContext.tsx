
import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole } from '../types';
import { authService } from '../services/authService';

interface AuthContextType {
  user: User | null;
  login: (email: string, pass: string) => Promise<User | null>;
  signup: (name: string, email: string, pass: string, role: UserRole) => Promise<User | null>;
  logout: () => void;
  loadingAuth: boolean;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);

  useEffect(() => {
    const currentlyLoggedInUser = authService.getCurrentUser();
    if (currentlyLoggedInUser) {
      setUser(currentlyLoggedInUser);
    }
    setLoadingAuth(false);
  }, []);

  const login = async (email: string, pass: string): Promise<User | null> => {
    setLoadingAuth(true);
    const loggedInUser = await authService.login(email, pass);
    setUser(loggedInUser);
    setLoadingAuth(false);
    return loggedInUser;
  };

  const signup = async (name: string, email: string, pass: string, role: UserRole): Promise<User | null> => {
    setLoadingAuth(true);
    const newUser = await authService.signup(name, email, pass, role);
    setUser(newUser);
    setLoadingAuth(false);
    return newUser;
  };

  const logout = () => {
    authService.logout();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, loadingAuth }}>
      {children}
    </AuthContext.Provider>
  );
};
