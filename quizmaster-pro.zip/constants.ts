
export const APP_NAME = "QuizMaster Pro";
export const API_KEY_ENV_VAR = "API_KEY"; // To remind that API_KEY comes from process.env

export const MIN_PASSWORD_LENGTH = 6;

export const DEFAULT_PASSING_SCORE = 70; // Default passing score percentage

export const GEMINI_TEXT_MODEL = "gemini-2.5-flash-preview-04-17";
// export const GEMINI_IMAGE_MODEL = "imagen-3.0-generate-002"; // If image generation was needed

export const LOCAL_STORAGE_USERS_KEY = 'quizmaster_users';
export const LOCAL_STORAGE_QUIZZES_KEY = 'quizmaster_quizzes';
export const LOCAL_STORAGE_SUBMISSIONS_KEY = 'quizmaster_submissions';
export const LOCAL_STORAGE_AUTH_USER_KEY = 'quizmaster_auth_user';

// Debounce time for inputs, e.g., AI suggestions
export const DEBOUNCE_DELAY = 500;
