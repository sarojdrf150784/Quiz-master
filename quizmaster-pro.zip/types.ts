
export enum UserRole {
  Teacher = 'teacher',
  Student = 'student',
}

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
}

export enum QuestionType {
  MultipleChoice = 'multiple-choice',
  TrueFalse = 'true-false',
  ShortAnswer = 'short-answer',
  Paragraph = 'paragraph',
  Matching = 'matching',
  FillInTheBlank = 'fill-in-the-blank',
}

export interface Option {
  id: string;
  text: string;
  isCorrect?: boolean; // For MCQ
}

export interface MatchItem {
  id: string;
  premise: string; // Left side
  response: string; // Right side (correct match)
}

export interface Question {
  id: string;
  type: QuestionType;
  text: string;
  points: number;
  options?: Option[]; // For MCQ
  correctAnswer?: boolean | string; // For True/False, ShortAnswer
  matchItems?: MatchItem[]; // For Matching
  // For FillInTheBlank, the 'text' will contain placeholders like "___"
  // The correct answers can be an array of strings corresponding to blanks.
  fillInBlanksAnswers?: string[]; 
}

export interface Quiz {
  id: string;
  title: string;
  instructions: string;
  timeLimitMinutes?: number; // Optional time limit in minutes
  passingScorePercentage: number;
  questions: Question[];
  teacherId: string;
  createdAt: string; // ISO date string
  updatedAt: string; // ISO date string
  isPublished: boolean;
  allowResultView: boolean; // Student can view their results immediately
}

export interface Answer {
  questionId: string;
  questionType: QuestionType;
  value?: string | string[] | boolean | { [key: string]: string }; // For MCQ (optionId), T/F (boolean), ShortAnswer/Paragraph (string), Matching (object of premiseId: responseText), FillInBlank (string[])
}

export interface QuizSubmission {
  id:string;
  quizId: string;
  studentId: string;
  studentName: string;
  answers: Answer[];
  score?: number; // Calculated score
  submittedAt: string; // ISO date string
  timeTakenSeconds?: number;
  gradedAt?: string; // ISO date string for manual grading
  isGraded: boolean;
}

// For Gemini Service
export interface AIPrompt {
  topic: string;
  questionType: QuestionType;
  targetAudience?: string; // e.g., "high school students"
}

export interface AISuggestedQuestion {
    text: string;
    options?: { text: string, isCorrect: boolean }[]; // For MCQ
    correctAnswer?: boolean | string; // For T/F, Short Answer
    // Add other fields if Gemini can provide them for other types
}
