
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import TeacherDashboardPage from './pages/TeacherDashboardPage';
import CreateQuizPage from './pages/CreateQuizPage';
import ViewQuizResultsPage from './pages/ViewQuizResultsPage';
import StudentDashboardPage from './pages/StudentDashboardPage';
import TakeQuizPage from './pages/TakeQuizPage';
import StudentQuizResultsPage from './pages/StudentQuizResultsPage';
import NotFoundPage from './pages/NotFoundPage';
import Header from './components/common/Header';
import Footer from './components/common/Footer';
import { useAuth } from './hooks/useAuth';
import { UserRole } from './types';

const App: React.FC = () => {
  const { user, loadingAuth } = useAuth();

  if (loadingAuth) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-100">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-primary-600"></div>
      </div>
    );
  }

  const TeacherProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (!user) return <Navigate to="/login" replace />;
    if (user.role !== UserRole.Teacher) return <Navigate to="/student/dashboard" replace />;
    return <>{children}</>;
  };

  const StudentProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (!user) return <Navigate to="/login" replace />;
    if (user.role !== UserRole.Student) return <Navigate to="/teacher/dashboard" replace />;
    return <>{children}</>;
  };
  
  const UnauthenticatedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    if (user) {
      return user.role === UserRole.Teacher ? <Navigate to="/teacher/dashboard" replace /> : <Navigate to="/student/dashboard" replace />;
    }
    return <>{children}</>;
  };


  return (
    <div className="flex flex-col min-h-screen bg-slate-50 text-slate-800">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={user ? (user.role === UserRole.Teacher ? <Navigate to="/teacher/dashboard" /> : <Navigate to="/student/dashboard" />) : <Navigate to="/login" />} />
          
          <Route path="/login" element={<UnauthenticatedRoute><LoginPage /></UnauthenticatedRoute>} />
          <Route path="/signup" element={<UnauthenticatedRoute><SignupPage /></UnauthenticatedRoute>} />

          {/* Teacher Routes */}
          <Route path="/teacher/dashboard" element={<TeacherProtectedRoute><TeacherDashboardPage /></TeacherProtectedRoute>} />
          <Route path="/teacher/create-quiz" element={<TeacherProtectedRoute><CreateQuizPage /></TeacherProtectedRoute>} />
          <Route path="/teacher/edit-quiz/:quizId" element={<TeacherProtectedRoute><CreateQuizPage editMode={true} /></TeacherProtectedRoute>} />
          <Route path="/teacher/view-results/:quizId" element={<TeacherProtectedRoute><ViewQuizResultsPage /></TeacherProtectedRoute>} />

          {/* Student Routes */}
          <Route path="/student/dashboard" element={<StudentProtectedRoute><StudentDashboardPage /></StudentProtectedRoute>} />
          <Route path="/student/take-quiz/:quizId" element={<StudentProtectedRoute><TakeQuizPage /></StudentProtectedRoute>} />
          <Route path="/student/results/:submissionId" element={<StudentProtectedRoute><StudentQuizResultsPage /></StudentProtectedRoute>} />
          
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
};

export default App;
