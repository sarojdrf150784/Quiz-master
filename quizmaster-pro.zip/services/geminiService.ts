
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AIPrompt, QuestionType, AISuggestedQuestion, Option as QuizOption } from '../types';
import { GEMINI_TEXT_MODEL } from '../constants';

// IMPORTANT: API Key must be set as an environment variable `process.env.API_KEY`
// This service assumes `process.env.API_KEY` is available in the execution environment.
// DO NOT ask the user for the API key in the UI.
const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;

const getAIClient = (): GoogleGenAI => {
  if (!ai) {
    if (!API_KEY) {
      console.error("API_KEY environment variable not set for Gemini API.");
      throw new Error("Gemini API key not configured.");
    }
    ai = new GoogleGenAI({ apiKey: API_KEY });
  }
  return ai;
};

const parseGeminiResponseToQuestion = (
    geminiText: string, 
    requestedType: QuestionType
): Partial<AISuggestedQuestion> | null => {
  let jsonStr = geminiText.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  
  try {
    const parsed = JSON.parse(jsonStr);
    const data = Array.isArray(parsed) ? parsed[0] : parsed;

    if (!data || typeof data.text !== 'string') {
        console.error("Parsed Gemini response does not have a text field or is not structured as expected:", data);
        return null;
    }
    
    const suggestedQuestion: Partial<AISuggestedQuestion> = { text: data.text };

    if (requestedType === QuestionType.MultipleChoice) {
      if (!Array.isArray(data.options) || data.options.length === 0) {
        console.warn("Gemini response for MCQ did not include a valid 'options' array or it was empty.", data);
        return null; 
      }

      const processedOptions: { text: string, isCorrect: boolean }[] = [];
      for (const opt of data.options) {
        // Ensure opt is an object and has a text property that is a non-empty string
        if (typeof opt === 'object' && opt !== null && typeof opt.text === 'string' && opt.text.trim() !== '') {
          processedOptions.push({
            text: opt.text,
            isCorrect: opt.isCorrect === true, // Coerce to boolean, defaults to false if undefined/incorrect type
          });
        } else {
          console.warn("Malformed or empty option text from AI suggestion:", opt);
        }
      }

      if (processedOptions.length === 0) {
        console.error("MCQ options provided by AI were all unusable (e.g., empty text). Original options:", data.options);
        return null; // Failed to create valid options.
      }
      if (!processedOptions.some(opt => opt.isCorrect)) {
        console.warn("AI-suggested MCQ has no correct option marked by the AI. Processed options:", processedOptions);
        // As per prompt, AI should mark one correct. If not, consider it a faulty suggestion.
        return null;
      }
      suggestedQuestion.options = processedOptions;

    } else if (requestedType === QuestionType.TrueFalse) {
      if (typeof data.correctAnswer !== 'boolean') {
        console.warn("Gemini response for True/False did not include a valid boolean 'correctAnswer'.", data);
        return null;
      }
      suggestedQuestion.correctAnswer = data.correctAnswer;
    } else if (requestedType === QuestionType.ShortAnswer) {
      if (typeof data.correctAnswer !== 'string') {
         // For short answer, correctAnswer might be optional if we allow AI to just suggest question text
         // However, our prompt asks for it. If it's missing or not a string, it's a deviation.
        console.warn("Gemini response for Short Answer did not include a string 'correctAnswer'.", data);
        // Depending on strictness, could return null or allow it if only text is needed.
        // Given the prompt asks for it, let's be strict for now.
        if (data.correctAnswer !== undefined) return null; // If present but wrong type, it's an error.
        // If completely absent, it might be okay if only question text was desired.
        // This part depends on how strictly we interpret the AI's role for short answers.
        // For now, we'll allow it to pass if correctAnswer is undefined, but log it.
      }
      suggestedQuestion.correctAnswer = data.correctAnswer; // Will be undefined if not provided
    }
    // Add parsers for other types if Gemini is prompted to provide structured data for them
    
    return suggestedQuestion;

  } catch (error) {
    console.error("Failed to parse Gemini response as JSON:", error, ". Raw text after fence removal:", jsonStr);
    return null; // If JSON.parse fails, the response is unusable for structured data.
  }
};


export const geminiService = {
  suggestQuestion: async (promptData: AIPrompt): Promise<Partial<AISuggestedQuestion> | null> => {
    const MAX_RETRIES = 2; // Total 3 attempts (1 initial + 2 retries)
    let client;
    try {
        client = getAIClient();
    } catch (error) {
        // This typically means API key is not set. getAIClient throws an error.
        console.error("Failed to initialize Gemini client:", error);
        if (error instanceof Error && (error.message.includes("API key") || error.message.includes("API_KEY"))) {
             alert("Gemini API Key is invalid or missing. Please ensure the API_KEY environment variable is correctly set up by the administrator.");
        }
        return null;
    }

    let specificInstructions = "";
    switch(promptData.questionType) {
      case QuestionType.MultipleChoice:
        specificInstructions = "Provide 4 options, with one marked as correct (e.g., options: [{text: 'Option A', isCorrect: false}, ...]). Ensure all options have non-empty text.";
        break;
      case QuestionType.TrueFalse:
        specificInstructions = "Provide the correct boolean answer (e.g., correctAnswer: true).";
        break;
      case QuestionType.ShortAnswer:
        specificInstructions = "Provide a concise correct answer string (e.g., correctAnswer: 'Paris').";
        break;
      case QuestionType.Paragraph:
           specificInstructions = "The question should require a paragraph-length answer. Do not provide a sample answer.";
           break;
      default:
          specificInstructions = "Ensure the question is appropriate for the type.";
    }

    const fullPrompt = `
      Generate a ${promptData.questionType} quiz question.
      Topic: ${promptData.topic}.
      ${promptData.targetAudience ? `Target Audience: ${promptData.targetAudience}.` : ''}
      ${specificInstructions}
      Return the response as a JSON object. For MCQ, the JSON should be like: {"text": "Question?", "options": [{"text": "Opt1", "isCorrect": true}, ...]}. 
      For True/False: {"text": "Statement?", "correctAnswer": boolean}.
      For Short Answer: {"text": "Question?", "correctAnswer": "Answer"}.
      For Paragraph: {"text": "Question requiring detailed answer."}.
      Only return the JSON object. Do not include any explanatory text before or after the JSON.
    `;

    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      try {
        const response: GenerateContentResponse = await client.models.generateContent({
          model: GEMINI_TEXT_MODEL,
          contents: fullPrompt,
          config: {
            responseMimeType: "application/json",
            temperature: 0.7,
          }
        });

        const textResponse = response.text;
        if (!textResponse) {
          console.warn(`Gemini API returned no text (attempt ${attempt + 1}/${MAX_RETRIES + 1}).`);
          if (attempt < MAX_RETRIES) {
            await new Promise(resolve => setTimeout(resolve, 500 * (attempt + 1))); // Linear backoff
            continue;
          }
          console.error("Gemini API returned no text after all retries.");
          return null;
        }
        
        const parsedQuestion = parseGeminiResponseToQuestion(textResponse, promptData.questionType);
        if (parsedQuestion) {
          return parsedQuestion; // Success
        } else {
          // Parsing failed, error already logged in parseGeminiResponseToQuestion
          console.warn(`Failed to parse Gemini response (attempt ${attempt + 1}/${MAX_RETRIES + 1}). Raw text: ${textResponse}`);
          if (attempt < MAX_RETRIES) {
            await new Promise(resolve => setTimeout(resolve, 500 * (attempt + 1))); // Linear backoff
            continue;
          }
          console.error("Failed to parse Gemini response after all retries.");
          return null;
        }

      } catch (error) {
        console.error(`Error calling Gemini API (attempt ${attempt + 1}/${MAX_RETRIES + 1}):`, error);
        if (error instanceof Error && (error.message.includes("API key") || error.message.includes("denied"))) {
            alert("Gemini API Key is invalid or missing. Please ensure the API_KEY environment variable is correctly set up by the administrator.");
            return null; // Don't retry for API key errors
        }
        if (attempt >= MAX_RETRIES) {
          console.error("All retries to Gemini API failed.");
          return null; // Return null after all retries failed
        }
        // Wait before retrying for other errors
        await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1))); // Longer, linear backoff for API errors
      }
    }
    return null; // Fallback, should ideally be covered by loop logic
  },
};
