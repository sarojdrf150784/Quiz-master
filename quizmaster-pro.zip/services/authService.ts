
import { User, UserRole } from '../types';
import { LOCAL_STORAGE_USERS_KEY, LOCAL_STORAGE_AUTH_USER_KEY } from '../constants';

// Helper to get users from localStorage
const getUsers = (): User[] => {
  const usersJson = localStorage.getItem(LOCAL_STORAGE_USERS_KEY);
  return usersJson ? JSON.parse(usersJson) : [];
};

// Helper to save users to localStorage
const saveUsers = (users: User[]): void => {
  localStorage.setItem(LOCAL_STORAGE_USERS_KEY, JSON.stringify(users));
};

// Helper to save authenticated user
const saveAuthUser = (user: User | null): void => {
  if (user) {
    localStorage.setItem(LOCAL_STORAGE_AUTH_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(LOCAL_STORAGE_AUTH_USER_KEY);
  }
}

// Helper to get authenticated user
const getAuthUser = (): User | null => {
  const userJson = localStorage.getItem(LOCAL_STORAGE_AUTH_USER_KEY);
  return userJson ? JSON.parse(userJson) : null;
}


export const authService = {
  login: async (email: string, pass: string): Promise<User | null> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    const users = getUsers();
    const user = users.find(u => u.email === email); // In a real app, password would be hashed and checked on backend
    
    // Simulate password check (THIS IS NOT SECURE FOR REAL APPS)
    if (user && localStorage.getItem(`password_${user.id}`) === pass) {
      saveAuthUser(user);
      return user;
    }
    saveAuthUser(null);
    return null;
  },

  signup: async (name: string, email: string, pass: string, role: UserRole): Promise<User | null> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const users = getUsers();
    if (users.some(u => u.email === email)) {
      // User already exists
      return null; 
    }
    const newUser: User = {
      id: Date.now().toString(), // Simple ID generation
      name,
      email,
      role,
    };
    users.push(newUser);
    saveUsers(users);
    // Simulate password storage (THIS IS NOT SECURE FOR REAL APPS)
    localStorage.setItem(`password_${newUser.id}`, pass);
    saveAuthUser(newUser);
    return newUser;
  },

  logout: (): void => {
    saveAuthUser(null);
  },

  getCurrentUser: (): User | null => {
    return getAuthUser();
  },
};
