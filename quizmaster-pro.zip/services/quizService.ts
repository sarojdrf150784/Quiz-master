
import { Quiz, Question, QuizSubmission, Answer, QuestionType } from '../types';
import { LOCAL_STORAGE_QUIZZES_KEY, LOCAL_STORAGE_SUBMISSIONS_KEY } from '../constants';

// Helper to get quizzes from localStorage
const getQuizzesLS = (): Quiz[] => {
  const quizzesJson = localStorage.getItem(LOCAL_STORAGE_QUIZZES_KEY);
  return quizzesJson ? JSON.parse(quizzesJson) : [];
};

// Helper to save quizzes to localStorage
const saveQuizzesLS = (quizzes: Quiz[]): void => {
  localStorage.setItem(LOCAL_STORAGE_QUIZZES_KEY, JSON.stringify(quizzes));
};

// Helper to get submissions from localStorage
const getSubmissionsLS = (): QuizSubmission[] => {
  const submissionsJson = localStorage.getItem(LOCAL_STORAGE_SUBMISSIONS_KEY);
  return submissionsJson ? JSON.parse(submissionsJson) : [];
};

// Helper to save submissions to localStorage
const saveSubmissionsLS = (submissions: QuizSubmission[]): void => {
  localStorage.setItem(LOCAL_STORAGE_SUBMISSIONS_KEY, JSON.stringify(submissions));
};

export const quizService = {
  // Quiz Management
  createQuiz: async (quizData: Omit<Quiz, 'id' | 'createdAt' | 'updatedAt'>): Promise<Quiz> => {
    await new Promise(resolve => setTimeout(resolve, 300)); // Simulate API delay
    const quizzes = getQuizzesLS();
    const newQuiz: Quiz = {
      ...quizData,
      id: `quiz_${Date.now().toString()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    quizzes.push(newQuiz);
    saveQuizzesLS(quizzes);
    return newQuiz;
  },

  getQuizById: async (quizId: string): Promise<Quiz | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    const quizzes = getQuizzesLS();
    return quizzes.find(q => q.id === quizId);
  },

  updateQuiz: async (quizId: string, updatedData: Partial<Quiz>): Promise<Quiz | null> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    let quizzes = getQuizzesLS();
    const quizIndex = quizzes.findIndex(q => q.id === quizId);
    if (quizIndex === -1) return null;

    quizzes[quizIndex] = { ...quizzes[quizIndex], ...updatedData, updatedAt: new Date().toISOString() };
    saveQuizzesLS(quizzes);
    return quizzes[quizIndex];
  },

  deleteQuiz: async (quizId: string): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    let quizzes = getQuizzesLS();
    const initialLength = quizzes.length;
    quizzes = quizzes.filter(q => q.id !== quizId);
    if (quizzes.length < initialLength) {
      saveQuizzesLS(quizzes);
      // Also delete related submissions
      let submissions = getSubmissionsLS();
      submissions = submissions.filter(s => s.quizId !== quizId);
      saveSubmissionsLS(submissions);
      return true;
    }
    return false;
  },

  getQuizzesByTeacher: async (teacherId: string): Promise<Quiz[]> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    const quizzes = getQuizzesLS();
    return quizzes.filter(q => q.teacherId === teacherId).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },
  
  getAllPublishedQuizzes: async (): Promise<Quiz[]> => { // For students to find quizzes by ID
    await new Promise(resolve => setTimeout(resolve, 200));
    const quizzes = getQuizzesLS();
    return quizzes.filter(q => q.isPublished);
  },

  // Submission Management
  submitQuiz: async (submissionData: Omit<QuizSubmission, 'id' | 'submittedAt' | 'score' | 'isGraded'>, quiz: Quiz): Promise<QuizSubmission> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const submissions = getSubmissionsLS();
    
    // Auto-grade MCQ and True/False
    let score = 0;
    submissionData.answers.forEach(answer => {
      const question = quiz.questions.find(q => q.id === answer.questionId);
      if (!question) return;

      switch (question.type) {
        case QuestionType.MultipleChoice:
          const selectedOption = question.options?.find(opt => opt.id === answer.value);
          if (selectedOption?.isCorrect) {
            score += question.points;
          }
          break;
        case QuestionType.TrueFalse:
          if (question.correctAnswer === answer.value) {
            score += question.points;
          }
          break;
        case QuestionType.ShortAnswer:
          // Auto-grading for short answer can be very basic, e.g. case-insensitive match
          if (typeof question.correctAnswer === 'string' && typeof answer.value === 'string' && question.correctAnswer.toLowerCase() === answer.value.toLowerCase()) {
             score += question.points;
          }
          // Otherwise, needs manual grading
          break;
        case QuestionType.FillInTheBlank:
            if (Array.isArray(question.fillInBlanksAnswers) && Array.isArray(answer.value)) {
                let correctBlanks = 0;
                const minLength = Math.min(question.fillInBlanksAnswers.length, (answer.value as string[]).length);
                for (let i = 0; i < minLength; i++) {
                    if (question.fillInBlanksAnswers[i].toLowerCase() === (answer.value as string[])[i]?.toLowerCase()) {
                        correctBlanks++;
                    }
                }
                if (correctBlanks === question.fillInBlanksAnswers.length) { // All blanks must be correct
                    score += question.points;
                }
            }
            break;
        // Paragraph and Matching typically require manual grading
        // For this simulation, they won't be auto-graded unless simple logic is added.
        default:
          break;
      }
    });
    
    const newSubmission: QuizSubmission = {
      ...submissionData,
      id: `sub_${Date.now().toString()}`,
      submittedAt: new Date().toISOString(),
      score: score,
      isGraded: ![QuestionType.Paragraph, QuestionType.Matching].some(type => quiz.questions.some(q => q.type === type)), // Mark as graded if no manual grading needed
    };
    submissions.push(newSubmission);
    saveSubmissionsLS(submissions);
    return newSubmission;
  },

  getSubmissionById: async (submissionId: string): Promise<QuizSubmission | undefined> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    const submissions = getSubmissionsLS();
    return submissions.find(s => s.id === submissionId);
  },

  getSubmissionsForQuiz: async (quizId: string): Promise<QuizSubmission[]> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    const submissions = getSubmissionsLS();
    return submissions.filter(s => s.quizId === quizId).sort((a,b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
  },

  getSubmissionsByStudent: async (studentId: string): Promise<QuizSubmission[]> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    const submissions = getSubmissionsLS();
    return submissions.filter(s => s.studentId === studentId).sort((a,b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
  },
  
  gradeSubmission: async (submissionId: string, updatedAnswersWithScores: Answer[], finalScore: number): Promise<QuizSubmission | null> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    let submissions = getSubmissionsLS();
    const subIndex = submissions.findIndex(s => s.id === submissionId);
    if (subIndex === -1) return null;

    submissions[subIndex] = {
      ...submissions[subIndex],
      answers: updatedAnswersWithScores, // Assuming answers might be updated if teacher corrects something
      score: finalScore,
      isGraded: true,
      gradedAt: new Date().toISOString(),
    };
    saveSubmissionsLS(submissions);
    return submissions[subIndex];
  },
};
