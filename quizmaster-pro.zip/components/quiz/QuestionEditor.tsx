
import React, { useState, useEffect, useCallback } from 'react';
import { Question, QuestionType, Option, MatchItem, AIPrompt, AISuggestedQuestion } from '../../types';
import Input, { Textarea } from '../common/Input';
import Button from '../common/Button';
import { geminiService } from '../../services/geminiService';
import { DEBOUNCE_DELAY } from '../../constants';

interface QuestionEditorProps {
  question: Question;
  onChange: (updatedQuestion: Question) => void;
  onRemove: () => void;
  index: number;
  quizTopic: string; // For AI suggestions
}

const TrashIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12.56 0c1.153 0 2.243.096 3.222.261m3.222.261L8.515 5.79m0 0a48.108 48.108 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
  </svg>
);
const SparklesIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L24 5.25l-.813 2.846a4.5 4.5 0 0 0-3.09 3.09L17.25 12l2.846.813a4.5 4.5 0 0 0 3.09 3.09L24 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L18.25 12Z" />
    </svg>
);
const PlusCircleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v6m3-3H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);


const QuestionEditor: React.FC<QuestionEditorProps> = ({ question, onChange, onRemove, index, quizTopic }) => {
  const [localQuestion, setLocalQuestion] = useState<Question>(question);
  const [isAISuggesting, setIsAISuggesting] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  useEffect(() => {
    setLocalQuestion(question);
  }, [question]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    let processedValue: string | number | boolean = value;
    if (type === 'number') processedValue = parseFloat(value) || 0;
    if (type === 'checkbox' && e.target instanceof HTMLInputElement) processedValue = e.target.checked;
    
    setLocalQuestion(prev => ({ ...prev, [name]: processedValue }));
  };
  
  const debouncedOnChange = useCallback(
    (updated: Question) => {
      onChange(updated);
    },
    [onChange] 
  );

  useEffect(() => {
    // Debounce the actual update to parent to avoid excessive re-renders while typing
    const handler = setTimeout(() => {
      if (JSON.stringify(localQuestion) !== JSON.stringify(question)) {
        debouncedOnChange(localQuestion);
      }
    }, DEBOUNCE_DELAY);
    return () => clearTimeout(handler);
  }, [localQuestion, question, debouncedOnChange]);


  // --- MCQ Specific ---
  const handleOptionChange = (optIndex: number, field: keyof Option, value: string | boolean) => {
    const newOptions = [...(localQuestion.options || [])];
    newOptions[optIndex] = { ...newOptions[optIndex], [field]: value };
    
    // If setting an option to correct, ensure others are not (for single-choice MCQ)
    if (field === 'isCorrect' && value === true) {
      newOptions.forEach((opt, i) => {
        if (i !== optIndex) opt.isCorrect = false;
      });
    }
    setLocalQuestion(prev => ({ ...prev, options: newOptions }));
  };

  const addOption = () => {
    const newOptions = [...(localQuestion.options || []), { id: `opt_${Date.now()}`, text: '', isCorrect: false }];
    setLocalQuestion(prev => ({ ...prev, options: newOptions }));
  };

  const removeOption = (optIndex: number) => {
    const newOptions = (localQuestion.options || []).filter((_, i) => i !== optIndex);
    setLocalQuestion(prev => ({ ...prev, options: newOptions }));
  };

  // --- True/False Specific ---
  const handleTrueFalseChange = (value: boolean) => {
    setLocalQuestion(prev => ({ ...prev, correctAnswer: value }));
  };

  // --- Matching Specific ---
  const handleMatchItemChange = (itemIndex: number, field: 'premise' | 'response', value: string) => {
    const newMatchItems = [...(localQuestion.matchItems || [])];
    newMatchItems[itemIndex] = { ...newMatchItems[itemIndex], [field]: value };
    setLocalQuestion(prev => ({ ...prev, matchItems: newMatchItems }));
  };

  const addMatchItem = () => {
    const newMatchItems = [...(localQuestion.matchItems || []), { id: `match_${Date.now()}`, premise: '', response: '' }];
    setLocalQuestion(prev => ({ ...prev, matchItems: newMatchItems }));
  };

  const removeMatchItem = (itemIndex: number) => {
    const newMatchItems = (localQuestion.matchItems || []).filter((_, i) => i !== itemIndex);
    setLocalQuestion(prev => ({ ...prev, matchItems: newMatchItems }));
  };

  // --- Fill-in-the-blank Specific ---
  const handleFillInBlankAnswerChange = (blankIndex: number, value: string) => {
    const newAnswers = [...(localQuestion.fillInBlanksAnswers || [])];
    newAnswers[blankIndex] = value;
    setLocalQuestion(prev => ({ ...prev, fillInBlanksAnswers: newAnswers }));
  };
  
  // Count blanks in question text to determine number of answer fields
  const blankCount = (localQuestion.text.match(/___/g) || []).length;
  useEffect(() => {
    if (localQuestion.type === QuestionType.FillInTheBlank) {
        const currentAnswers = localQuestion.fillInBlanksAnswers || [];
        if (currentAnswers.length !== blankCount) {
            const newAnswers = Array(blankCount).fill('').map((_, i) => currentAnswers[i] || '');
            setLocalQuestion(prev => ({ ...prev, fillInBlanksAnswers: newAnswers }));
        }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [blankCount, localQuestion.type]); // Only re-run if blankCount or type changes


  const handleAISuggest = async () => {
    if (!quizTopic && localQuestion.type !== QuestionType.Paragraph && localQuestion.type !== QuestionType.ShortAnswer) {
      setAiError("Quiz topic must be set for AI suggestions for this question type.");
      return;
    }
    setIsAISuggesting(true);
    setAiError(null);
    const promptData: AIPrompt = {
      topic: quizTopic || "general knowledge", // Fallback topic
      questionType: localQuestion.type,
    };
    const suggestion = await geminiService.suggestQuestion(promptData);
    setIsAISuggesting(false);
    if (suggestion && suggestion.text) {
      let updatedQuestion = { ...localQuestion, text: suggestion.text };
      if (suggestion.options && localQuestion.type === QuestionType.MultipleChoice) {
        updatedQuestion.options = suggestion.options.map((opt, i) => ({ id: `opt_ai_${i}_${Date.now()}`, text: opt.text, isCorrect: opt.isCorrect }));
      }
      if (suggestion.correctAnswer !== undefined) {
          if (localQuestion.type === QuestionType.TrueFalse && typeof suggestion.correctAnswer === 'boolean') {
            updatedQuestion.correctAnswer = suggestion.correctAnswer;
          } else if (localQuestion.type === QuestionType.ShortAnswer && typeof suggestion.correctAnswer === 'string') {
            updatedQuestion.correctAnswer = suggestion.correctAnswer;
          }
      }
      setLocalQuestion(updatedQuestion);
    } else {
      setAiError("Failed to get AI suggestion. Please check console or ensure API key is set.");
    }
  };

  return (
    <div className="p-4 border border-slate-300 rounded-lg mb-6 bg-slate-50 shadow">
      <div className="flex justify-between items-center mb-4">
        <h4 className="text-md font-semibold text-slate-700">Question {index + 1}</h4>
        <div className="flex items-center space-x-2">
            <Button onClick={handleAISuggest} size="sm" variant="secondary" isLoading={isAISuggesting} icon={<SparklesIcon />} title="Suggest with AI">
                AI
            </Button>
            <Button onClick={onRemove} variant="danger" size="sm" icon={<TrashIcon />} title="Remove Question"/>
        </div>
      </div>
      {aiError && <p className="text-xs text-red-500 mb-2">{aiError}</p>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label htmlFor={`q_type_${localQuestion.id}`} className="block text-sm font-medium text-slate-700 mb-1">Type</label>
          <select
            id={`q_type_${localQuestion.id}`}
            name="type"
            value={localQuestion.type}
            onChange={handleInputChange}
            className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm focus:outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500"
          >
            {Object.values(QuestionType).map(qt => <option key={qt} value={qt}>{qt.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}</option>)}
          </select>
        </div>
        <Input
          label="Points"
          type="number"
          name="points"
          value={localQuestion.points}
          onChange={handleInputChange}
          min="0"
          containerClassName="mb-0"
        />
      </div>
      
      <Textarea
        label="Question Text"
        name="text"
        value={localQuestion.text}
        onChange={handleInputChange}
        placeholder={localQuestion.type === QuestionType.FillInTheBlank ? "Example: The capital of France is ___. Paris is in ___." : "Enter question text here..."}
        rows={localQuestion.type === QuestionType.Paragraph ? 4 : 2}
      />
      {localQuestion.type === QuestionType.FillInTheBlank && (
        <p className="text-xs text-slate-500 mb-2">Use three underscores `___` for each blank.</p>
      )}


      {/* Type-Specific Editors */}
      {localQuestion.type === QuestionType.MultipleChoice && (
        <div className="mt-4">
          <h5 className="text-sm font-semibold text-slate-600 mb-2">Options</h5>
          {(localQuestion.options || []).map((opt, optIndex) => (
            <div key={opt.id || optIndex} className="flex items-center space-x-2 mb-2 p-2 border border-slate-200 rounded-md">
              <input 
                type="text" 
                value={opt.text} 
                onChange={(e) => handleOptionChange(optIndex, 'text', e.target.value)}
                placeholder={`Option ${optIndex + 1}`}
                className="flex-grow px-2 py-1 border border-slate-300 rounded-md text-sm"
              />
              <label className="flex items-center space-x-1 text-sm">
                <input 
                  type="checkbox" 
                  checked={opt.isCorrect || false}
                  onChange={(e) => handleOptionChange(optIndex, 'isCorrect', e.target.checked)}
                  className="form-checkbox h-4 w-4 text-primary-600 border-slate-300 rounded focus:ring-primary-500"
                />
                <span>Correct</span>
              </label>
              <Button onClick={() => removeOption(optIndex)} variant="danger" size="sm" className="p-1">
                <TrashIcon />
              </Button>
            </div>
          ))}
          <Button onClick={addOption} size="sm" variant="secondary" icon={<PlusCircleIcon />}>Add Option</Button>
        </div>
      )}

      {localQuestion.type === QuestionType.TrueFalse && (
        <div className="mt-4">
          <h5 className="text-sm font-semibold text-slate-600 mb-1">Correct Answer</h5>
          <div className="flex space-x-4">
            <label className="flex items-center space-x-1 text-sm">
              <input 
                type="radio" 
                name={`tf_answer_${localQuestion.id}`} 
                checked={localQuestion.correctAnswer === true} 
                onChange={() => handleTrueFalseChange(true)}
                className="form-radio h-4 w-4 text-primary-600 border-slate-300 focus:ring-primary-500"
              />
              <span>True</span>
            </label>
            <label className="flex items-center space-x-1 text-sm">
              <input 
                type="radio" 
                name={`tf_answer_${localQuestion.id}`} 
                checked={localQuestion.correctAnswer === false} 
                onChange={() => handleTrueFalseChange(false)}
                className="form-radio h-4 w-4 text-primary-600 border-slate-300 focus:ring-primary-500"
              />
              <span>False</span>
            </label>
          </div>
        </div>
      )}

      {localQuestion.type === QuestionType.ShortAnswer && (
        <div className="mt-4">
          <Input
            label="Correct Answer (optional, for auto-grading)"
            type="text"
            name="correctAnswer"
            value={typeof localQuestion.correctAnswer === 'string' ? localQuestion.correctAnswer : ''}
            onChange={handleInputChange}
            placeholder="Enter the exact correct answer"
            containerClassName="mb-0"
          />
           <p className="text-xs text-slate-500 mt-1">Auto-grading is case-insensitive. Leave blank for manual grading.</p>
        </div>
      )}
      
      {localQuestion.type === QuestionType.Paragraph && (
         <p className="mt-2 text-sm text-slate-600">Paragraph questions are manually graded.</p>
      )}

      {localQuestion.type === QuestionType.Matching && (
        <div className="mt-4">
          <h5 className="text-sm font-semibold text-slate-600 mb-2">Matching Pairs</h5>
          {(localQuestion.matchItems || []).map((item, itemIndex) => (
            <div key={item.id || itemIndex} className="grid grid-cols-2 gap-2 mb-2 p-2 border border-slate-200 rounded-md items-center">
              <Input
                type="text"
                value={item.premise}
                onChange={(e) => handleMatchItemChange(itemIndex, 'premise', e.target.value)}
                placeholder={`Premise ${itemIndex + 1}`}
                containerClassName="mb-0"
              />
              <div className="flex items-center space-x-2">
                <Input
                  type="text"
                  value={item.response}
                  onChange={(e) => handleMatchItemChange(itemIndex, 'response', e.target.value)}
                  placeholder={`Correct Match ${itemIndex + 1}`}
                  containerClassName="mb-0 flex-grow"
                />
                <Button onClick={() => removeMatchItem(itemIndex)} variant="danger" size="sm" className="p-1 self-start mt-1">
                    <TrashIcon/>
                </Button>
              </div>
            </div>
          ))}
          <Button onClick={addMatchItem} size="sm" variant="secondary" icon={<PlusCircleIcon />}>Add Pair</Button>
          <p className="mt-2 text-sm text-slate-600">Matching questions are typically manually graded.</p>
        </div>
      )}

      {localQuestion.type === QuestionType.FillInTheBlank && blankCount > 0 && (
        <div className="mt-4">
          <h5 className="text-sm font-semibold text-slate-600 mb-2">Correct Answers for Blanks</h5>
          {Array(blankCount).fill(null).map((_, i) => (
            <Input
              key={`blank_ans_${i}`}
              label={`Answer for blank ${i + 1}`}
              type="text"
              value={(localQuestion.fillInBlanksAnswers || [])[i] || ''}
              onChange={(e) => handleFillInBlankAnswerChange(i, e.target.value)}
              placeholder={`Correct text for blank ${i + 1}`}
              containerClassName="mb-2"
            />
          ))}
          <p className="text-xs text-slate-500 mt-1">Auto-grading is case-insensitive. All blanks must be correct for points.</p>
        </div>
      )}
    </div>
  );
};

export default QuestionEditor;
