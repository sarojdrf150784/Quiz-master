
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { APP_NAME } from '../../constants';
import { UserRole } from '../../types';

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const UserIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-1">
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
    </svg>
  );
  
  const LogoutIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-1">
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9" />
    </svg>
  );


  return (
    <header className="bg-primary-700 text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold hover:text-primary-200 transition-colors">
          {APP_NAME}
        </Link>
        <nav className="flex items-center space-x-4">
          {user ? (
            <>
              <span className="flex items-center text-sm">
                <UserIcon /> {user.name} ({user.role})
              </span>
              {user.role === UserRole.Teacher && (
                <Link to="/teacher/dashboard" className="hover:text-primary-200 transition-colors">Dashboard</Link>
              )}
              {user.role === UserRole.Student && (
                <Link to="/student/dashboard" className="hover:text-primary-200 transition-colors">Dashboard</Link>
              )}
              <button
                onClick={handleLogout}
                className="flex items-center bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-3 rounded-md text-sm transition-colors"
              >
                <LogoutIcon /> Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="hover:text-primary-200 transition-colors">Login</Link>
              <Link to="/signup" className="bg-primary-500 hover:bg-primary-600 text-white font-semibold py-2 px-3 rounded-md text-sm transition-colors">Sign Up</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;
