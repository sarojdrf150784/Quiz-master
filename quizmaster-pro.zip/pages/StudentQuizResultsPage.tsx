
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { quizService } from '../services/quizService';
import { Quiz, QuizSubmission, Question, Answer, QuestionType } from '../types';
import { useAuth } from '../hooks/useAuth';
import LoadingSpinner from '../components/common/LoadingSpinner';
import Card from '../components/common/Card';

const CheckCircleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-green-500 mr-1">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);
const XCircleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-red-500 mr-1">
        <path strokeLinecap="round" strokeLinejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);
const MinusCircleIcon = () => ( // For questions pending manual grading or not fully auto-gradable for correctness display
     <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-yellow-500 mr-1">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12H9m12 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);


const StudentQuizResultsPage: React.FC = () => {
  const { submissionId } = useParams<{ submissionId: string }>();
  const { user } = useAuth();
  const [submission, setSubmission] = useState<QuizSubmission | null>(null);
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    if (!submissionId || !user) return;
    setIsLoading(true);
    setError(null);
    try {
      const subData = await quizService.getSubmissionById(submissionId);
      if (subData && subData.studentId === user.id) {
        setSubmission(subData);
        const quizData = await quizService.getQuizById(subData.quizId);
        if (quizData) {
          if (!quizData.allowResultView) {
            setError("Results for this quiz are not currently viewable.");
            setQuiz(null); // Prevent rendering quiz details
            setSubmission(null);
          } else {
            setQuiz(quizData);
          }
        } else {
          setError("Associated quiz not found.");
        }
      } else {
        setError("Submission not found or you do not have permission to view it.");
      }
    } catch (err) {
      console.error("Error fetching results:", err);
      setError("Failed to load results. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [submissionId, user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const isAnswerCorrect = (answer: Answer, question: Question): boolean | null => {
    // Returns true if correct, false if incorrect, null if not auto-gradable for correctness display
    switch (question.type) {
        case QuestionType.MultipleChoice:
            const selectedOption = question.options?.find(opt => opt.id === answer.value);
            return selectedOption?.isCorrect || false;
        case QuestionType.TrueFalse:
            return question.correctAnswer === answer.value;
        case QuestionType.ShortAnswer:
            if (question.correctAnswer === undefined) return null; // Needs manual grade for correctness
            return typeof question.correctAnswer === 'string' && typeof answer.value === 'string' && question.correctAnswer.toLowerCase() === answer.value.toLowerCase();
        case QuestionType.FillInTheBlank:
            if (!question.fillInBlanksAnswers || !Array.isArray(answer.value) || question.fillInBlanksAnswers.length !== (answer.value as string[]).length) return false; // Incomplete or mismatched
            return question.fillInBlanksAnswers.every((correct, idx) => correct.toLowerCase() === (answer.value as string[])[idx]?.toLowerCase());
        case QuestionType.Matching: // Typically manually graded for overall correctness
        case QuestionType.Paragraph:
            return null; 
        default:
            return null;
    }
  };
  
  const getAnswerDisplay = (answerValue: any, questionType: QuestionType, question: Question): React.ReactNode => {
    switch (questionType) {
        case QuestionType.MultipleChoice:
            const option = question.options?.find(opt => opt.id === answerValue);
            return option?.text || "Invalid option";
        case QuestionType.TrueFalse:
            return String(answerValue);
        case QuestionType.ShortAnswer:
        case QuestionType.Paragraph:
            return <p className="whitespace-pre-wrap">{String(answerValue)}</p>;
        case QuestionType.Matching:
            const matches = answerValue as { [key: string]: string };
            if (!matches || typeof matches !== 'object') return "Invalid match data";
            return (
                <ul className="list-disc list-inside text-sm">
                {Object.entries(matches).map(([premiseId, responseText]) => {
                    const premiseItem = question.matchItems?.find(mi => mi.id === premiseId);
                    // For student view, we might not show correctness per match item unless teacher feedback provides it
                    return <li key={premiseId}>{premiseItem?.premise || 'Unknown Premise'}: {responseText}</li>;
                })}
                </ul>
            );
        case QuestionType.FillInTheBlank:
            const blankAnswers = answerValue as string[];
            if (!Array.isArray(blankAnswers)) return "Invalid blank answers";
             return (
                <ol className="list-decimal list-inside text-sm">
                {blankAnswers.map((ansText, idx) => (
                    <li key={idx}>Blank {idx+1}: {ansText}</li>
                ))}
                </ol>
            );
        default:
            return String(answerValue);
    }
  };


  if (isLoading) {
    return <div className="text-center py-10"><LoadingSpinner /> <p className="mt-2">Loading your results...</p></div>;
  }

  if (error) {
    return <div className="text-center py-10 text-red-500 bg-red-100 p-4 rounded-md">{error}</div>;
  }

  if (!submission || !quiz) {
    return <div className="text-center py-10">Results data not available. <Link to="/student/dashboard" className="text-primary-600 hover:underline">Go to Dashboard</Link></div>;
  }
  
  const totalPossiblePoints = quiz.questions.reduce((sum, q) => sum + q.points, 0);
  const percentageScore = totalPossiblePoints > 0 && submission.score !== undefined ? (submission.score / totalPossiblePoints) * 100 : 0;
  const passed = submission.score !== undefined && percentageScore >= quiz.passingScorePercentage;

  return (
    <div className="max-w-3xl mx-auto space-y-8">
       <Link to="/student/dashboard" className="text-sm text-primary-600 hover:underline mb-2 block">&larr; Back to Dashboard</Link>
      <Card title={`Results for: ${quiz.title}`}>
        <div className="p-6 text-center border-b border-slate-200">
          <h2 className="text-2xl font-bold">Your Score: {submission.score ?? 'Pending'} / {totalPossiblePoints}</h2>
          {submission.score !== undefined && (
             <p className={`text-xl font-semibold ${passed ? 'text-green-600' : 'text-red-600'}`}>
                {percentageScore.toFixed(1)}% - {passed ? 'Passed!' : 'Failed'}
            </p>
          )}
          {!submission.isGraded && <p className="text-sm text-yellow-600 mt-1">(Some questions may require manual grading by your teacher)</p>}
          <p className="text-sm text-slate-500 mt-1">Submitted: {new Date(submission.submittedAt).toLocaleString()}</p>
          {submission.timeTakenSeconds && <p className="text-sm text-slate-500">Time Taken: {Math.floor(submission.timeTakenSeconds/60)}m {submission.timeTakenSeconds%60}s</p>}
        </div>

        <div className="p-6 space-y-6">
          <h3 className="text-xl font-semibold text-slate-800">Detailed Answers:</h3>
          {quiz.questions.map((question, index) => {
            const answer = submission.answers.find(ans => ans.questionId === question.id);
            const correctness = answer ? isAnswerCorrect(answer, question) : false;

            return (
              <div key={question.id} className="p-4 border border-slate-200 rounded-md bg-slate-50">
                <div className="flex justify-between items-start">
                    <p className="font-semibold text-slate-700">Q{index + 1}: {question.text}</p>
                    <span className="text-xs text-slate-500 whitespace-nowrap">({question.points} pts)</span>
                </div>
                
                <div className="mt-2 text-sm text-slate-800">
                  <strong>Your Answer: </strong>
                  {answer ? getAnswerDisplay(answer.value, question.type, question) : <span className="text-slate-400 italic">Not answered</span>}
                </div>

                { submission.isGraded && answer && ( /* Show correctness only if fully graded and answered */
                    <div className="mt-2 text-sm flex items-center">
                        {correctness === true && <><CheckCircleIcon /> Correct</>}
                        {correctness === false && <><XCircleIcon /> Incorrect</>}
                        {correctness === null && <><MinusCircleIcon /> Review by teacher</>}
                    </div>
                )}
                
                {/* Optionally show correct answer if question type supports it and teacher allows */}
                { submission.isGraded && answer && correctness === false && (
                    (question.type === QuestionType.MultipleChoice && question.options?.find(opt => opt.isCorrect)) ||
                    (question.type === QuestionType.TrueFalse && question.correctAnswer !== undefined) ||
                    (question.type === QuestionType.ShortAnswer && question.correctAnswer !== undefined) ||
                    (question.type === QuestionType.FillInTheBlank && question.fillInBlanksAnswers)
                   ) && (
                    <div className="mt-1 text-xs text-green-700 bg-green-50 p-2 rounded">
                        <strong>Correct Answer: </strong>
                        {question.type === QuestionType.MultipleChoice && question.options?.find(opt => opt.isCorrect)?.text}
                        {question.type === QuestionType.TrueFalse && String(question.correctAnswer)}
                        {question.type === QuestionType.ShortAnswer && String(question.correctAnswer)}
                        {question.type === QuestionType.FillInTheBlank && question.fillInBlanksAnswers?.join(', ')}
                    </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
};

export default StudentQuizResultsPage;
