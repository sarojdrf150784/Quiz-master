
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { quizService } from '../services/quizService';
import { Quiz, QuizSubmission } from '../types';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import Card from '../components/common/Card';
import LoadingSpinner from '../components/common/LoadingSpinner';

const PlayIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
        <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 0 1 0 1.972l-11.54 6.347a1.125 1.125 0 0 1-1.667-.986V5.653Z" />
    </svg>
);
const DocumentTextIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
    </svg>
);


const StudentDashboardPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [quizCode, setQuizCode] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [recentSubmissions, setRecentSubmissions] = useState<QuizSubmission[]>([]);
  const [availableQuizzes, setAvailableQuizzes] = useState<Quiz[]>([]); // To store quiz details for recent submissions
  const [loadingSubmissions, setLoadingSubmissions] = useState(true);

  const fetchRecentSubmissions = useCallback(async () => {
    if (!user) return;
    setLoadingSubmissions(true);
    try {
      const submissions = await quizService.getSubmissionsByStudent(user.id);
      setRecentSubmissions(submissions.slice(0, 5)); // Show latest 5

      // Fetch quiz details for these submissions to display quiz titles
      const quizIds = [...new Set(submissions.map(s => s.quizId))];
      const quizzesPromises = quizIds.map(id => quizService.getQuizById(id));
      const quizzesResults = (await Promise.all(quizzesPromises)).filter(q => q !== undefined) as Quiz[];
      setAvailableQuizzes(quizzesResults);

    } catch (err) {
      console.error("Error fetching recent submissions:", err);
      setError("Could not load your recent activity.");
    } finally {
      setLoadingSubmissions(false);
    }
  }, [user]);

  useEffect(() => {
    fetchRecentSubmissions();
  }, [fetchRecentSubmissions]);

  const handleAccessQuiz = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!quizCode.trim()) {
      setError('Please enter a quiz ID.');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      // Students find quizzes by ID from all published quizzes
      const allPublishedQuizzes = await quizService.getAllPublishedQuizzes();
      const quiz = allPublishedQuizzes.find(q => q.id === quizCode.trim() && q.isPublished);

      if (quiz) {
        // Check if student already submitted this quiz
        const studentSubmissions = await quizService.getSubmissionsByStudent(user!.id);
        const existingSubmission = studentSubmissions.find(s => s.quizId === quiz.id);
        if(existingSubmission) {
            // If teacher allows viewing results, navigate there. Otherwise, show message.
            if (quiz.allowResultView) {
                 navigate(`/student/results/${existingSubmission.id}`);
            } else {
                 setError("You have already completed this quiz. Results are not viewable at this time.");
            }
        } else {
            navigate(`/student/take-quiz/${quiz.id}`);
        }
      } else {
        setError('Quiz not found or is not available. Please check the ID and try again.');
      }
    } catch (err) {
      console.error("Error accessing quiz:", err);
      setError('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getQuizTitle = (quizId: string): string => {
    const quiz = availableQuizzes.find(q => q.id === quizId);
    return quiz?.title || "Quiz";
  }
  
  const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString();


  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-slate-800">Welcome, {user?.name}!</h1>

      <Card title="Access a Quiz">
        <form onSubmit={handleAccessQuiz} className="space-y-4">
          <Input
            label="Enter Quiz ID"
            type="text"
            value={quizCode}
            onChange={(e) => setQuizCode(e.target.value)}
            placeholder="e.g., quiz_123456789"
            error={error}
            required
          />
          <Button type="submit" variant="primary" isLoading={isLoading} icon={<PlayIcon />} size="lg">
            {isLoading ? 'Accessing...' : 'Start Quiz'}
          </Button>
        </form>
      </Card>

      <Card title="Recent Activity">
        {loadingSubmissions ? (
          <div className="text-center py-6"><LoadingSpinner size="md" /></div>
        ) : recentSubmissions.length > 0 ? (
          <ul className="divide-y divide-slate-200">
            {recentSubmissions.map(sub => (
              <li key={sub.id} className="py-4 flex justify-between items-center">
                <div>
                  <p className="text-md font-semibold text-primary-700">{getQuizTitle(sub.quizId)}</p>
                  <p className="text-sm text-slate-500">
                    Submitted: {formatDate(sub.submittedAt)} - Score: {sub.score !== undefined ? `${sub.score} (${((sub.score / (availableQuizzes.find(q=>q.id === sub.quizId)?.questions.reduce((acc,curr)=>acc+curr.points,0) || 1)) * 100).toFixed(0)}%)` : 'Pending'}
                  </p>
                </div>
                { (availableQuizzes.find(q => q.id === sub.quizId)?.allowResultView && sub.isGraded) &&
                    <Button 
                        onClick={() => navigate(`/student/results/${sub.id}`)} 
                        variant="secondary" 
                        size="sm"
                        icon={<DocumentTextIcon />}
                    >
                        View Results
                    </Button>
                }
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-center text-slate-500 py-6">You haven't attempted any quizzes yet.</p>
        )}
      </Card>
    </div>
  );
};

export default StudentDashboardPage;
