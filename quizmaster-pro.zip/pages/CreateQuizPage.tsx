
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { quizService } from '../services/quizService';
import { Quiz, Question, QuestionType, Option, MatchItem } from '../types';
import Input, { Textarea } from '../components/common/Input';
import Button from '../components/common/Button';
import QuestionEditor from '../components/quiz/QuestionEditor';
import Card from '../components/common/Card';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { DEFAULT_PASSING_SCORE } from '../constants';

const PlusIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
  </svg>
);
const SaveIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 3.75H6.912a2.25 2.25 0 0 0-2.15 1.588L2.35 13.177a2.25 2.25 0 0 0-.1.661V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18v-4.162c0-.224-.034-.447-.1-.661L19.24 5.338a2.25 2.25 0 0 0-2.15-1.588H15M2.25 13.5h3.86a2.25 2.25 0 0 1 2.012 1.244l.256.512a2.25 2.25 0 0 0 2.013 1.244h3.218a2.25 2.25 0 0 0 2.013-1.244l.256-.512a2.25 2.25 0 0 1 2.013-1.244h3.859M12 3v8.25m0 0-3-3m3 3 3-3" />
    </svg>
);
const PublishIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 8.25H7.5a2.25 2.25 0 0 0-2.25 2.25v9a2.25 2.25 0 0 0 2.25 2.25h9a2.25 2.25 0 0 0 2.25-2.25v-9a2.25 2.25 0 0 0-2.25-2.25H15M9 12l3 3m0 0 3-3m-3 3V2.25" />
    </svg>
);


interface CreateQuizPageProps {
  editMode?: boolean;
}

const CreateQuizPage: React.FC<CreateQuizPageProps> = ({ editMode = false }) => {
  const { quizId } = useParams<{ quizId?: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [quiz, setQuiz] = useState<Partial<Quiz>>({
    title: '',
    instructions: '',
    timeLimitMinutes: undefined,
    passingScorePercentage: DEFAULT_PASSING_SCORE,
    questions: [],
    isPublished: false,
    allowResultView: true, // Default to allow students to see results
  });
  const [isLoading, setIsLoading] = useState(false);
  const [pageLoading, setPageLoading] = useState(editMode); // For fetching quiz in edit mode
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (editMode && quizId && user) {
      setPageLoading(true);
      quizService.getQuizById(quizId)
        .then(fetchedQuiz => {
          if (fetchedQuiz && fetchedQuiz.teacherId === user.id) {
            setQuiz(fetchedQuiz);
          } else {
            setError("Quiz not found or you don't have permission to edit it.");
            navigate('/teacher/dashboard');
          }
        })
        .catch(err => {
          console.error("Error fetching quiz for edit:", err);
          setError("Failed to load quiz data.");
        })
        .finally(() => setPageLoading(false));
    } else if (!editMode) {
        // Reset for new quiz form
        setQuiz({
            title: '', instructions: '', timeLimitMinutes: undefined, 
            passingScorePercentage: DEFAULT_PASSING_SCORE, questions: [], 
            isPublished: false, allowResultView: true
        });
    }
  }, [editMode, quizId, user, navigate]);

  const handleQuizMetaChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setQuiz(prev => ({
      ...prev,
      [name]: type === 'number' ? (value === '' ? undefined : parseFloat(value)) : value,
    }));
  };

  const handleQuestionChange = useCallback((index: number, updatedQuestion: Question) => {
    setQuiz(prev => {
      const newQuestions = [...(prev.questions || [])];
      newQuestions[index] = updatedQuestion;
      return { ...prev, questions: newQuestions };
    });
  }, []);

  const addQuestion = () => {
    const newQuestion: Question = {
      id: `q_${Date.now()}`,
      type: QuestionType.MultipleChoice,
      text: '',
      points: 10,
      options: [{id: `opt_${Date.now()}_1`, text: '', isCorrect: true}, {id: `opt_${Date.now()}_2`, text: '', isCorrect: false}], // Default MCQ structure
    };
    setQuiz(prev => ({ ...prev, questions: [...(prev.questions || []), newQuestion] }));
  };

  const removeQuestion = (index: number) => {
    setQuiz(prev => ({ ...prev, questions: (prev.questions || []).filter((_, i) => i !== index) }));
  };

  const validateQuiz = (): boolean => {
    if (!quiz.title?.trim()) {
      setError("Quiz title is required.");
      return false;
    }
    if (!quiz.questions || quiz.questions.length === 0) {
      setError("Quiz must have at least one question.");
      return false;
    }
    for (const q of quiz.questions) {
      if (!q.text.trim()) {
        setError(`Question "${q.id}" text cannot be empty.`);
        return false;
      }
      if (q.points <= 0) {
        setError(`Question "${q.id}" points must be greater than 0.`);
        return false;
      }
      if (q.type === QuestionType.MultipleChoice) {
        if (!q.options || q.options.length < 2) {
          setError(`MCQ "${q.id}" must have at least two options.`);
          return false;
        }
        if (!q.options.some(opt => opt.isCorrect)) {
          setError(`MCQ "${q.id}" must have at least one correct option.`);
          return false;
        }
        if (q.options.some(opt => !opt.text.trim())) {
            setError(`MCQ "${q.id}" options cannot be empty.`);
            return false;
        }
      }
      // Add more validations for other types if necessary
    }
    setError(null);
    return true;
  };

  const handleSubmit = async (publishQuiz: boolean = false) => {
    if (!user) {
      setError("User not authenticated.");
      return;
    }
    if (!validateQuiz()) return;

    setIsLoading(true);
    setError(null);

    const quizDataToSave = {
      ...quiz,
      teacherId: user.id,
      isPublished: publishQuiz || quiz.isPublished || false, // If explicitly publishing, or keep current state
    } as Omit<Quiz, 'id' | 'createdAt' | 'updatedAt'>; // Type assertion for create

    try {
      if (editMode && quizId) {
        await quizService.updateQuiz(quizId, quizDataToSave);
      } else {
        await quizService.createQuiz(quizDataToSave);
      }
      navigate('/teacher/dashboard');
    } catch (err) {
      console.error("Error saving quiz:", err);
      setError("Failed to save quiz. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleTogglePublished = () => {
    setQuiz(prev => ({ ...prev, isPublished: !prev.isPublished }));
  };
  
  const handleToggleAllowResultView = () => {
    setQuiz(prev => ({ ...prev, allowResultView: !prev.allowResultView }));
  };

  if (pageLoading) {
    return <div className="text-center py-10"><LoadingSpinner /> <p className="mt-2">Loading quiz editor...</p></div>;
  }
  
  if (error && !editMode && !quizId) { // Show general error if not specific to fetching an existing quiz
      // This state might be cleared if user starts typing, good.
  }


  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-slate-800">{editMode ? 'Edit Quiz' : 'Create New Quiz'}</h1>
      
      {error && <div className="p-3 bg-red-100 text-red-700 rounded-md mb-4">{error}</div>}

      <Card title="Quiz Details">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input
            label="Quiz Title"
            name="title"
            value={quiz.title || ''}
            onChange={handleQuizMetaChange}
            required
            placeholder="e.g., Chapter 1 Review"
          />
          <Input
            label="Time Limit (minutes, optional)"
            type="number"
            name="timeLimitMinutes"
            value={quiz.timeLimitMinutes === undefined ? '' : quiz.timeLimitMinutes}
            onChange={handleQuizMetaChange}
            min="0"
            placeholder="e.g., 60"
          />
        </div>
        <Textarea
          label="Instructions"
          name="instructions"
          value={quiz.instructions || ''}
          onChange={handleQuizMetaChange}
          placeholder="e.g., Read each question carefully. You have one attempt."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
           <Input
            label="Passing Score (%)"
            type="number"
            name="passingScorePercentage"
            value={quiz.passingScorePercentage || ''}
            onChange={handleQuizMetaChange}
            min="0" max="100" required
          />
          <div className="space-y-2">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={quiz.isPublished || false}
                onChange={handleTogglePublished}
                className="form-checkbox h-5 w-5 text-primary-600 border-slate-300 rounded focus:ring-primary-500"
              />
              <span className="text-sm text-slate-700">Publish Quiz (students can access with ID)</span>
            </label>
             <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={quiz.allowResultView || false}
                onChange={handleToggleAllowResultView}
                className="form-checkbox h-5 w-5 text-primary-600 border-slate-300 rounded focus:ring-primary-500"
              />
              <span className="text-sm text-slate-700">Allow students to view results immediately after submission</span>
            </label>
          </div>
        </div>
      </Card>

      <Card title="Questions">
        {quiz.questions && quiz.questions.map((q, index) => (
          <QuestionEditor
            key={q.id}
            question={q}
            index={index}
            onChange={(updatedQ) => handleQuestionChange(index, updatedQ)}
            onRemove={() => removeQuestion(index)}
            quizTopic={quiz.title || ''}
          />
        ))}
        <Button onClick={addQuestion} variant="secondary" icon={<PlusIcon />}>Add Question</Button>
      </Card>

      <div className="flex flex-col sm:flex-row justify-end space-y-3 sm:space-y-0 sm:space-x-3 mt-8">
        <Button onClick={() => handleSubmit(quiz.isPublished)} variant="primary" isLoading={isLoading} icon={<SaveIcon />} size="lg">
          {isLoading ? 'Saving...' : (editMode ? 'Save Changes' : 'Save Quiz')}
        </Button>
        {!quiz.isPublished && (
            <Button onClick={() => handleSubmit(true)} variant="success" isLoading={isLoading} icon={<PublishIcon />} size="lg">
                {isLoading ? 'Publishing...' : 'Save & Publish'}
            </Button>
        )}
        <Button onClick={() => navigate('/teacher/dashboard')} variant="secondary" size="lg" disabled={isLoading}>
          Cancel
        </Button>
      </div>
    </div>
  );
};

export default CreateQuizPage;
