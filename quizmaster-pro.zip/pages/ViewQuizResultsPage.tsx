
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { quizService } from '../services/quizService';
import { Quiz, QuizSubmission, QuestionType, Answer } from '../types';
import LoadingSpinner from '../components/common/LoadingSpinner';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Modal from '../components/common/Modal';
import Input from '../components/common/Input';

const DownloadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
    </svg>
);
const CheckCircleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-green-500">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);
const XCircleIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-red-500">
        <path strokeLinecap="round" strokeLinejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);


const ViewQuizResultsPage: React.FC = () => {
  const { quizId } = useParams<{ quizId: string }>();
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [submissions, setSubmissions] = useState<QuizSubmission[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [selectedSubmission, setSelectedSubmission] = useState<QuizSubmission | null>(null);
  const [isGradingModalOpen, setIsGradingModalOpen] = useState(false);
  const [manualScores, setManualScores] = useState<{[questionId: string]: number}>({});

  const fetchQuizData = useCallback(async () => {
    if (!quizId) return;
    setIsLoading(true);
    setError(null);
    try {
      const [quizData, submissionData] = await Promise.all([
        quizService.getQuizById(quizId),
        quizService.getSubmissionsForQuiz(quizId),
      ]);
      if (quizData) {
        setQuiz(quizData);
        setSubmissions(submissionData);
      } else {
        setError("Quiz not found.");
      }
    } catch (err) {
      console.error("Error fetching quiz results:", err);
      setError("Failed to load quiz results.");
    } finally {
      setIsLoading(false);
    }
  }, [quizId]);

  useEffect(() => {
    fetchQuizData();
  }, [fetchQuizData]);

  const exportToCSV = () => {
    if (!quiz || submissions.length === 0) return;

    const headers = ['Student Name', 'Student ID', 'Score', 'Submitted At', 'Time Taken (s)'];
    quiz.questions.forEach(q => headers.push(`Q${quiz.questions.indexOf(q) + 1}: ${q.text.substring(0,30)}... (${q.points} pts)`));
    
    const rows = submissions.map(sub => {
      const row = [
        sub.studentName,
        sub.studentId,
        sub.score ?? 'N/A',
        new Date(sub.submittedAt).toLocaleString(),
        sub.timeTakenSeconds ?? 'N/A',
      ];
      quiz.questions.forEach(q => {
        const answer = sub.answers.find(a => a.questionId === q.id);
        let displayValue = "Not Answered";
        if (answer) {
            if (q.type === QuestionType.MultipleChoice) {
                const option = q.options?.find(opt => opt.id === answer.value);
                displayValue = option ? option.text : "Invalid Option";
            } else if (q.type === QuestionType.TrueFalse) {
                displayValue = String(answer.value);
            } else if (q.type === QuestionType.Matching) {
                // For matching, join premise-response pairs
                const matchedItems = answer.value as { [key: string]: string };
                displayValue = Object.entries(matchedItems)
                    .map(([premiseId, responseText]) => {
                        const premiseItem = q.matchItems?.find(mi => mi.id === premiseId);
                        return `${premiseItem?.premise || 'Unknown Premise'} -> ${responseText}`;
                    }).join('; ');
            } else if (q.type === QuestionType.FillInTheBlank && Array.isArray(answer.value)) {
                displayValue = (answer.value as string[]).join(', ');
            }
            else {
                displayValue = String(answer.value);
            }
        }
        row.push(displayValue);
      });
      return row.join(',');
    });

    const csvContent = "data:text/csv;charset=utf-8," + headers.join(',') + "\n" + rows.join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `quiz_results_${quiz.title.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const openGradingModal = (submission: QuizSubmission) => {
    setSelectedSubmission(submission);
    const initialScores: {[questionId: string]: number} = {};
    quiz?.questions.forEach(q => {
        // For subjective questions, if already graded, use that score, else default to 0
        // For auto-graded ones, find their score
        const answer = submission.answers.find(ans => ans.questionId === q.id);
        if (answer) {
           // This is tricky: need to re-evaluate initial score for the question for grading UI
           // For now, let's assume manual grading starts fresh or we show current points for that question
           let questionScore = 0;
           // This part is simplified, a more robust system would store per-question scores.
           // For now, if it's a manually gradable question, default its part of the score to 0 for the input.
           if (q.type === QuestionType.Paragraph || q.type === QuestionType.Matching || (q.type === QuestionType.ShortAnswer && !q.correctAnswer)) {
             // If there was a pre-existing part of score for this (e.g. if teacher is re-grading), it's complex.
             // For simplicity, let's just allow overriding for now.
             // This simulation doesn't store per-question scores for manually graded items explicitly.
             // So, we'll just let teacher assign points up to q.points.
             questionScore = 0; // Teacher will fill this
           } else { // Auto-graded questions, try to deduce current points for this question
              // This is a simplification. True per-question score during initial auto-grading is needed.
              // For now, just indicate the points it *could* get.
           }
           initialScores[q.id] = questionScore; // This logic needs refinement for showing previous manual grades
        }
    });
    setManualScores(initialScores);
    setIsGradingModalOpen(true);
  };

  const handleScoreChange = (questionId: string, score: string) => {
    const question = quiz?.questions.find(q => q.id === questionId);
    if (!question) return;
    let numScore = parseFloat(score);
    if (isNaN(numScore)) numScore = 0;
    if (numScore < 0) numScore = 0;
    if (numScore > question.points) numScore = question.points;
    
    setManualScores(prev => ({...prev, [questionId]: numScore }));
  };
  
  const handleSaveGrade = async () => {
    if (!selectedSubmission || !quiz) return;
    
    let finalScore = 0;
    const updatedAnswers = selectedSubmission.answers.map(ans => ({ ...ans })); // shallow copy

    quiz.questions.forEach(q => {
        const answer = updatedAnswers.find(a => a.questionId === q.id);
        if(!answer) return;

        if (q.type === QuestionType.Paragraph || q.type === QuestionType.Matching || (q.type === QuestionType.ShortAnswer && !q.correctAnswer) || manualScores[q.id] !== undefined) {
            // If it's a manually graded question type OR if a score was explicitly set for it in the modal
            finalScore += manualScores[q.id] || 0;
        } else {
            // For auto-graded questions, re-calculate their contribution if not overridden
            // This logic should ideally use the original auto-grading logic from quizService
            let questionScore = 0;
            if (q.type === QuestionType.MultipleChoice) {
                const selectedOption = q.options?.find(opt => opt.id === answer.value);
                if (selectedOption?.isCorrect) questionScore = q.points;
            } else if (q.type === QuestionType.TrueFalse) {
                if (q.correctAnswer === answer.value) questionScore = q.points;
            } else if (q.type === QuestionType.ShortAnswer && q.correctAnswer) {
                 if (typeof q.correctAnswer === 'string' && typeof answer.value === 'string' && q.correctAnswer.toLowerCase() === answer.value.toLowerCase()) {
                    questionScore = q.points;
                 }
            } else if (q.type === QuestionType.FillInTheBlank && Array.isArray(q.fillInBlanksAnswers) && Array.isArray(answer.value)) {
                let correctBlanks = 0;
                const minLength = Math.min(q.fillInBlanksAnswers.length, (answer.value as string[]).length);
                for (let i = 0; i < minLength; i++) {
                    if (q.fillInBlanksAnswers[i].toLowerCase() === (answer.value as string[])[i]?.toLowerCase()) {
                        correctBlanks++;
                    }
                }
                if (correctBlanks === q.fillInBlanksAnswers.length) {
                    questionScore = q.points;
                }
            }
            finalScore += questionScore;
        }
    });
    
    setIsLoading(true);
    try {
      await quizService.gradeSubmission(selectedSubmission.id, updatedAnswers, finalScore);
      await fetchQuizData(); // Refresh data
      setIsGradingModalOpen(false);
      setSelectedSubmission(null);
    } catch (e) {
      setError("Failed to save grade.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const getAnswerDisplay = (answer: Answer, questionId: string): React.ReactNode => {
    const question = quiz?.questions.find(q => q.id === questionId);
    if (!question) return "N/A";

    switch (question.type) {
        case QuestionType.MultipleChoice:
            const option = question.options?.find(opt => opt.id === answer.value);
            return <span className={option?.isCorrect ? 'text-green-600 font-semibold' : 'text-red-600'}>{option?.text || "Invalid option"}</span>;
        case QuestionType.TrueFalse:
            const isCorrectTF = question.correctAnswer === answer.value;
            return <span className={isCorrectTF ? 'text-green-600 font-semibold' : 'text-red-600'}>{String(answer.value)}</span>;
        case QuestionType.ShortAnswer:
            const isCorrectSA = typeof question.correctAnswer === 'string' && typeof answer.value === 'string' && question.correctAnswer.toLowerCase() === answer.value.toLowerCase();
            return <span className={question.correctAnswer && isCorrectSA ? 'text-green-600 font-semibold' : (question.correctAnswer ? 'text-red-600' : '')}>{String(answer.value)}</span>;
        case QuestionType.Paragraph:
            return <p className="text-sm text-slate-700 whitespace-pre-wrap">{String(answer.value)}</p>;
        case QuestionType.Matching:
            const matches = answer.value as { [key: string]: string };
            if (!matches || typeof matches !== 'object') return "Invalid match data";
            return (
                <ul className="list-disc list-inside text-sm">
                {Object.entries(matches).map(([premiseId, responseText]) => {
                    const premiseItem = question.matchItems?.find(mi => mi.id === premiseId);
                    const isCorrectMatch = premiseItem?.response === responseText; // Simplified check
                    return <li key={premiseId} className={isCorrectMatch ? 'text-green-600' : 'text-red-600'}>{premiseItem?.premise || 'Unknown'}: {responseText}</li>;
                })}
                </ul>
            );
        case QuestionType.FillInTheBlank:
            const blankAnswers = answer.value as string[];
            if (!Array.isArray(blankAnswers)) return "Invalid blank answers";
            return (
                <ol className="list-decimal list-inside text-sm">
                {blankAnswers.map((ansText, idx) => {
                    const isCorrectBlank = question.fillInBlanksAnswers && question.fillInBlanksAnswers[idx]?.toLowerCase() === ansText.toLowerCase();
                    return <li key={idx} className={isCorrectBlank ? 'text-green-600' : 'text-red-600'}>Blank {idx+1}: {ansText}</li>
                })}
                </ol>
            );
        default:
            return String(answer.value);
    }
  };


  if (isLoading) {
    return <div className="text-center py-10"><LoadingSpinner /> <p className="mt-2">Loading results...</p></div>;
  }

  if (error) {
    return <div className="text-center py-10 text-red-500 bg-red-100 p-4 rounded-md">{error}</div>;
  }

  if (!quiz) {
    return <div className="text-center py-10">Quiz data not available.</div>;
  }
  
  const totalPossiblePoints = quiz.questions.reduce((sum, q) => sum + q.points, 0);

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
            <Link to="/teacher/dashboard" className="text-sm text-primary-600 hover:underline mb-2 block">&larr; Back to Dashboard</Link>
            <h1 className="text-3xl font-bold text-slate-800 truncate" title={quiz.title}>Results: {quiz.title}</h1>
        </div>
        <Button onClick={exportToCSV} icon={<DownloadIcon />} variant="secondary" disabled={submissions.length === 0}>
          Export CSV
        </Button>
      </div>

      {submissions.length === 0 ? (
        <Card>
          <p className="text-center text-slate-500 py-8">No submissions for this quiz yet.</p>
        </Card>
      ) : (
        <Card title={`Submissions (${submissions.length})`} className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Student</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Score</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Submitted</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {submissions.map(sub => (
                <tr key={sub.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{sub.studentName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                    {sub.score !== undefined ? `${sub.score} / ${totalPossiblePoints}` : 'N/A'} 
                    {sub.score !== undefined && totalPossiblePoints > 0 ? ` (${((sub.score/totalPossiblePoints)*100).toFixed(1)}%)` : ''}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{new Date(sub.submittedAt).toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {sub.isGraded ? 
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Graded</span> : 
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">Pending</span>
                    }
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <Button onClick={() => openGradingModal(sub)} size="sm" variant="primary">
                      {sub.isGraded ? 'View/Regrade' : 'Grade'}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {selectedSubmission && quiz && (
        <Modal
          isOpen={isGradingModalOpen}
          onClose={() => setIsGradingModalOpen(false)}
          title={`Grading: ${selectedSubmission.studentName} - ${quiz.title}`}
          footer={
            <>
              <Button variant="secondary" onClick={() => setIsGradingModalOpen(false)}>Cancel</Button>
              <Button variant="primary" onClick={handleSaveGrade} isLoading={isLoading}>Save Grades</Button>
            </>
          }
        >
          <div className="space-y-6">
            {quiz.questions.map((q, index) => {
              const answer = selectedSubmission.answers.find(a => a.questionId === q.id);
              const needsManualGrading = q.type === QuestionType.Paragraph || q.type === QuestionType.Matching || (q.type === QuestionType.ShortAnswer && !q.correctAnswer);
              
              return (
                <div key={q.id} className="p-4 border border-slate-200 rounded-md bg-slate-50">
                  <p className="font-semibold text-slate-700">Q{index + 1}: {q.text} ({q.points} pts)</p>
                  <div className="mt-2 text-sm text-slate-600">
                    <strong>Student's Answer:</strong>
                    {answer ? getAnswerDisplay(answer, q.id) : <span className="text-slate-400 italic">Not answered</span>}
                  </div>
                  { (q.type === QuestionType.MultipleChoice && questionHasCorrectAnswer(q) && answer) &&
                    <p className="mt-1 text-xs text-slate-500">Correct: {q.options?.find(opt => opt.isCorrect)?.text}</p>
                  }
                  { (q.type === QuestionType.TrueFalse && q.correctAnswer !== undefined && answer) &&
                    <p className="mt-1 text-xs text-slate-500">Correct: {String(q.correctAnswer)}</p>
                  }
                  { (q.type === QuestionType.ShortAnswer && q.correctAnswer && answer) &&
                    <p className="mt-1 text-xs text-slate-500">Suggested Correct: {String(q.correctAnswer)}</p>
                  }
                   { (q.type === QuestionType.FillInTheBlank && q.fillInBlanksAnswers && q.fillInBlanksAnswers.length > 0 && answer) &&
                    <p className="mt-1 text-xs text-slate-500">Correct Blanks: {q.fillInBlanksAnswers.join(', ')}</p>
                  }

                  {needsManualGrading || true ? ( // Allow score adjustment for all questions in this UI
                    <div className="mt-3">
                      <Input
                        label="Assign Score for this Question:"
                        type="number"
                        value={manualScores[q.id] === undefined ? '' : manualScores[q.id]}
                        onChange={(e) => handleScoreChange(q.id, e.target.value)}
                        max={q.points}
                        min={0}
                        placeholder={`0 - ${q.points}`}
                        containerClassName="max-w-xs"
                      />
                    </div>
                  ) : (
                    <div className="mt-2 text-sm">
                        {/* Logic for auto-graded indication */}
                        {isAnswerCorrect(answer, q) ? 
                            <span className="flex items-center text-green-600"><CheckCircleIcon /> Auto-graded: Correct ({q.points} pts)</span> : 
                            <span className="flex items-center text-red-600"><XCircleIcon /> Auto-graded: Incorrect (0 pts)</span>
                        }
                    </div>
                  )}
                </div>
              );
            })}
            <div className="mt-6 pt-4 border-t text-right font-semibold">
                Total Score: {Object.values(manualScores).reduce((sum, s) => sum + (s || 0), 0)} / {totalPossiblePoints}
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

// Helper functions to determine correctness for display in modal (simplified)
const questionHasCorrectAnswer = (q: Quiz['questions'][0]): boolean => {
    if (q.type === QuestionType.MultipleChoice) return !!q.options?.some(o => o.isCorrect);
    if (q.type === QuestionType.TrueFalse) return q.correctAnswer !== undefined;
    if (q.type === QuestionType.ShortAnswer) return q.correctAnswer !== undefined;
    if (q.type === QuestionType.FillInTheBlank) return !!q.fillInBlanksAnswers && q.fillInBlanksAnswers.length > 0;
    return false;
}

const isAnswerCorrect = (answer: Answer | undefined, question: Quiz['questions'][0]): boolean => {
    if (!answer) return false;
    switch (question.type) {
        case QuestionType.MultipleChoice:
            return !!question.options?.find(opt => opt.id === answer.value && opt.isCorrect);
        case QuestionType.TrueFalse:
            return question.correctAnswer === answer.value;
        case QuestionType.ShortAnswer:
             if (!question.correctAnswer) return false; // cannot auto-grade
             return typeof question.correctAnswer === 'string' && typeof answer.value === 'string' && question.correctAnswer.toLowerCase() === answer.value.toLowerCase();
        case QuestionType.FillInTheBlank:
            if (!question.fillInBlanksAnswers || !Array.isArray(answer.value)) return false;
            if (question.fillInBlanksAnswers.length !== (answer.value as string[]).length) return false;
            return question.fillInBlanksAnswers.every((correctAns, idx) => correctAns.toLowerCase() === (answer.value as string[])[idx]?.toLowerCase());
        default: return false; // Not auto-gradable by this simple check
    }
};

export default ViewQuizResultsPage;
