
import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { quizService } from '../services/quizService';
import { Quiz } from '../types';
import Button from '../components/common/Button';
import LoadingSpinner from '../components/common/LoadingSpinner';
import Card from '../components/common/Card';

const PlusIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
  </svg>
);
const EyeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
    </svg>
);
const PencilIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
        <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
    </svg>
);
const TrashIconSmall = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
        <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12.56 0c1.153 0 2.243.096 3.222.261m3.222.261L8.515 5.79m0 0a48.108 48.108 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
    </svg>
);


const TeacherDashboardPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchQuizzes = useCallback(async () => {
    if (!user) return;
    setIsLoading(true);
    setError(null);
    try {
      const fetchedQuizzes = await quizService.getQuizzesByTeacher(user.id);
      setQuizzes(fetchedQuizzes);
    } catch (err) {
      console.error("Error fetching quizzes:", err);
      setError("Failed to load quizzes. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchQuizzes();
  }, [fetchQuizzes]);

  const handleDeleteQuiz = async (quizId: string) => {
    if (window.confirm("Are you sure you want to delete this quiz and all its submissions? This action cannot be undone.")) {
      setIsLoading(true); // You might want a more specific loading state for deletion
      try {
        await quizService.deleteQuiz(quizId);
        setQuizzes(prevQuizzes => prevQuizzes.filter(q => q.id !== quizId));
      } catch (err) {
        console.error("Error deleting quiz:", err);
        setError("Failed to delete quiz. Please try again.");
      } finally {
        setIsLoading(false);
      }
    }
  };

  if (isLoading && quizzes.length === 0) {
    return <div className="text-center py-10"><LoadingSpinner /> <p className="mt-2">Loading your quizzes...</p></div>;
  }

  if (error) {
    return <div className="text-center py-10 text-red-500 bg-red-100 p-4 rounded-md">{error}</div>;
  }
  
  const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString();

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-slate-800">My Quizzes</h1>
        <Button onClick={() => navigate('/teacher/create-quiz')} icon={<PlusIcon />} variant="primary">
          Create New Quiz
        </Button>
      </div>

      {quizzes.length === 0 && !isLoading ? (
        <Card>
          <div className="text-center py-10">
            <h2 className="text-xl font-semibold text-slate-700">No quizzes yet!</h2>
            <p className="text-slate-500 mt-2">Click "Create New Quiz" to get started.</p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map(quiz => (
            <Card key={quiz.id} className="flex flex-col justify-between hover:shadow-xl transition-shadow duration-300">
              <div>
                <div className="px-6 py-4 border-b border-slate-200">
                    <h3 className="text-lg font-semibold text-primary-700 truncate" title={quiz.title}>{quiz.title}</h3>
                    <p className={`text-xs font-medium px-2 py-0.5 rounded-full inline-block ${quiz.isPublished ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                        {quiz.isPublished ? 'Published' : 'Draft'}
                    </p>
                </div>
                <div className="p-6">
                    <p className="text-sm text-slate-600 mb-1 line-clamp-2" title={quiz.instructions}>{quiz.instructions || "No instructions provided."}</p>
                    <p className="text-xs text-slate-500">Questions: {quiz.questions.length}</p>
                    <p className="text-xs text-slate-500">Time Limit: {quiz.timeLimitMinutes ? `${quiz.timeLimitMinutes} min` : 'None'}</p>
                    <p className="text-xs text-slate-500">Passing: {quiz.passingScorePercentage}%</p>
                    <p className="text-xs text-slate-500">Created: {formatDate(quiz.createdAt)}</p>
                    {quiz.isPublished && <p className="mt-2 text-xs text-slate-500">Share ID: <strong className="text-slate-700 select-all">{quiz.id}</strong></p>}
                </div>
              </div>
              <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end space-x-2">
                <Button onClick={() => navigate(`/teacher/view-results/${quiz.id}`)} size="sm" variant="secondary" icon={<EyeIcon />}>
                  Results
                </Button>
                <Button onClick={() => navigate(`/teacher/edit-quiz/${quiz.id}`)} size="sm" variant="secondary" icon={<PencilIcon />}>
                  Edit
                </Button>
                <Button onClick={() => handleDeleteQuiz(quiz.id)} size="sm" variant="danger" icon={<TrashIconSmall />}>
                  Delete
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default TeacherDashboardPage;
