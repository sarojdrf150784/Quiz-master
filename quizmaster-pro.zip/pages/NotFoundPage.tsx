
import React from 'react';
import { Link } from 'react-router-dom';
import Card from '../components/common/Card';
import Button from '../components/common/Button';

const NotFoundPage: React.FC = () => {
  return (
    <div className="flex items-center justify-center py-12 text-center">
      <Card className="w-full max-w-lg">
        <img src="https://picsum.photos/seed/quiz404/400/200" alt="Confused person looking at a map" className="mx-auto mb-8 rounded-md shadow-md" />
        <h1 className="text-5xl font-bold text-primary-600 mb-4">404</h1>
        <h2 className="text-2xl font-semibold text-slate-800 mb-3">Oops! Page Not Found.</h2>
        <p className="text-slate-600 mb-8">
          The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
        </p>
        <Button onClick={() => window.history.back()} variant="secondary" className="mr-3">
          Go Back
        </Button>
        <Link to="/">
          <Button variant="primary">
            Go to Homepage
          </Button>
        </Link>
      </Card>
    </div>
  );
};

export default NotFoundPage;
