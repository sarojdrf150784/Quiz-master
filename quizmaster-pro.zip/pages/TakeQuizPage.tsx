
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { quizService } from '../services/quizService';
import { Quiz, Question, Answer, QuestionType, QuizSubmission } from '../types';
import { useAuth } from '../hooks/useAuth';
import LoadingSpinner from '../components/common/LoadingSpinner';
import Button from '../components/common/Button';
import Card from '../components/common/Card';
import Modal from '../components/common/Modal';

const ClockIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
);


const TakeQuizPage: React.FC = () => {
  const { quizId } = useParams<{ quizId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const timerRef = useRef<number | null>(null); // Changed NodeJS.Timeout to number
  const startTimeRef = useRef<Date | null>(null);

  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const fetchQuiz = useCallback(async () => {
    if (!quizId || !user) return;
    setIsLoading(true);
    setError(null);
    try {
      const fetchedQuiz = await quizService.getQuizById(quizId);
      if (fetchedQuiz && fetchedQuiz.isPublished) {
         // Check if student already submitted this quiz
        const studentSubmissions = await quizService.getSubmissionsByStudent(user.id);
        const existingSubmission = studentSubmissions.find(s => s.quizId === fetchedQuiz.id);
        if(existingSubmission) {
            alert("You have already completed this quiz."); // Or navigate to results if allowed
            if(fetchedQuiz.allowResultView) navigate(`/student/results/${existingSubmission.id}`);
            else navigate('/student/dashboard');
            return;
        }

        setQuiz(fetchedQuiz);
        setAnswers(fetchedQuiz.questions.map(q => ({ questionId: q.id, questionType: q.type, value: getDefaultAnswerValue(q.type) })));
        if (fetchedQuiz.timeLimitMinutes) {
          setTimeLeft(fetchedQuiz.timeLimitMinutes * 60);
        }
        startTimeRef.current = new Date();
      } else {
        setError("Quiz not found or is not available.");
        navigate('/student/dashboard');
      }
    } catch (err) {
      console.error("Error fetching quiz:", err);
      setError("Failed to load quiz. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [quizId, user, navigate]);

  useEffect(() => {
    fetchQuiz();
  }, [fetchQuiz]);

  // Timer logic
  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0) {
      if (timerRef.current) clearInterval(timerRef.current);
      if (timeLeft === 0) handleSubmitQuiz(true); // Auto-submit when time is up
      return;
    }
    // @ts-ignore
    timerRef.current = setInterval(() => {
      setTimeLeft(prevTime => (prevTime !== null ? prevTime - 1 : null));
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeLeft]); // handleSubmitQuiz dependency removed to avoid re-triggering

  const getDefaultAnswerValue = (type: QuestionType): any => {
    switch (type) {
      case QuestionType.MultipleChoice: return ''; // optionId string
      case QuestionType.TrueFalse: return undefined; // boolean
      case QuestionType.ShortAnswer: return ''; // string
      case QuestionType.Paragraph: return ''; // string
      case QuestionType.Matching: return {}; // { premiseId: responseText }
      case QuestionType.FillInTheBlank: return []; // string[]
      default: return undefined;
    }
  };

  const handleAnswerChange = (questionId: string, questionType: QuestionType, value: any) => {
    setAnswers(prevAnswers =>
      prevAnswers.map(ans =>
        ans.questionId === questionId ? { ...ans, value } : ans
      )
    );
  };
  
  // Specific handler for Matching
  const handleMatchingAnswerChange = (questionId: string, premiseId: string, responseText: string) => {
    setAnswers(prevAnswers =>
      prevAnswers.map(ans => {
        if (ans.questionId === questionId) {
          const currentMatchValue = (ans.value as { [key: string]: string } || {});
          return { ...ans, value: { ...currentMatchValue, [premiseId]: responseText } };
        }
        return ans;
      })
    );
  };

  // Specific handler for FillInTheBlank
  const handleFillInBlankAnswerChange = (questionId: string, blankIndex: number, text: string) => {
      setAnswers(prevAnswers => 
          prevAnswers.map(ans => {
              if (ans.questionId === questionId) {
                  const currentBlankValues = Array.isArray(ans.value) ? [...ans.value] : [];
                  currentBlankValues[blankIndex] = text;
                  return { ...ans, value: currentBlankValues };
              }
              return ans;
          })
      );
  };


  const handleSubmitQuiz = useCallback(async (autoSubmitted: boolean = false) => {
    if (!quiz || !user || isSubmitting) return;

    setShowConfirmModal(false);
    setIsSubmitting(true);
    setError(null);
    
    if (timerRef.current) clearInterval(timerRef.current);
    const endTime = new Date();
    const timeTakenSeconds = startTimeRef.current ? Math.round((endTime.getTime() - startTimeRef.current.getTime()) / 1000) : undefined;

    const submissionData: Omit<QuizSubmission, 'id' | 'submittedAt' | 'score' | 'isGraded'> = {
      quizId: quiz.id,
      studentId: user.id,
      studentName: user.name,
      answers,
      timeTakenSeconds,
    };

    try {
      const submissionResult = await quizService.submitQuiz(submissionData, quiz);
      if (autoSubmitted) {
        alert("Time's up! Your quiz has been automatically submitted.");
      }
      if(quiz.allowResultView){
        navigate(`/student/results/${submissionResult.id}`);
      } else {
        alert("Quiz submitted successfully! Your teacher will review your submission.");
        navigate('/student/dashboard');
      }
    } catch (err) {
      console.error("Error submitting quiz:", err);
      setError("Failed to submit quiz. Please try again.");
      setIsSubmitting(false); // Allow retry
    }
    // No finally setIsLoading(false) here as we navigate away on success.
  }, [quiz, user, answers, navigate, isSubmitting]);


  const formatTime = (totalSeconds: number | null): string => {
    if (totalSeconds === null) return 'N/A';
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  if (isLoading) {
    return <div className="text-center py-10"><LoadingSpinner /> <p className="mt-2">Loading quiz...</p></div>;
  }

  if (error) {
    return <div className="text-center py-10 text-red-500 bg-red-100 p-4 rounded-md">{error}</div>;
  }

  if (!quiz) {
    return <div className="text-center py-10">Quiz not found.</div>;
  }

  const currentQuestion: Question | undefined = quiz.questions[currentQuestionIndex];
  const currentAnswer = answers.find(ans => ans.questionId === currentQuestion?.id);

  const renderQuestionContent = () => {
    if (!currentQuestion || !currentAnswer) return null;

    switch (currentQuestion.type) {
      case QuestionType.MultipleChoice:
        return (
          <div className="space-y-3">
            {currentQuestion.options?.map(opt => (
              <label key={opt.id} className="flex items-center p-3 border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="radio"
                  name={currentQuestion.id}
                  value={opt.id}
                  checked={currentAnswer.value === opt.id}
                  onChange={() => handleAnswerChange(currentQuestion.id, currentQuestion.type, opt.id)}
                  className="form-radio h-5 w-5 text-primary-600 border-slate-300 focus:ring-primary-500 mr-3"
                />
                <span className="text-slate-700">{opt.text}</span>
              </label>
            ))}
          </div>
        );
      case QuestionType.TrueFalse:
        return (
          <div className="flex space-x-4">
            {[true, false].map(val => (
              <label key={String(val)} className="flex items-center p-3 border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer transition-colors flex-1 justify-center">
                <input
                  type="radio"
                  name={currentQuestion.id}
                  checked={currentAnswer.value === val}
                  onChange={() => handleAnswerChange(currentQuestion.id, currentQuestion.type, val)}
                  className="form-radio h-5 w-5 text-primary-600 border-slate-300 focus:ring-primary-500 mr-3"
                />
                <span className="text-slate-700 capitalize">{String(val)}</span>
              </label>
            ))}
          </div>
        );
      case QuestionType.ShortAnswer:
        return (
          <input
            type="text"
            value={currentAnswer.value as string || ''}
            onChange={(e) => handleAnswerChange(currentQuestion.id, currentQuestion.type, e.target.value)}
            className="w-full p-3 border border-slate-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
            placeholder="Your answer here..."
          />
        );
      case QuestionType.Paragraph:
        return (
          <textarea
            value={currentAnswer.value as string || ''}
            onChange={(e) => handleAnswerChange(currentQuestion.id, currentQuestion.type, e.target.value)}
            rows={5}
            className="w-full p-3 border border-slate-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
            placeholder="Your detailed answer here..."
          />
        );
      case QuestionType.Matching:
        const premises = currentQuestion.matchItems?.map(item => ({id: item.id, text: item.premise})) || [];
        // Create a shuffled list of responses for students to pick from for each premise
        const responses = currentQuestion.matchItems?.map(item => ({id: item.id, text: item.response})).sort(() => Math.random() - 0.5) || []; 
        return (
          <div className="space-y-3">
            {premises.map(premise => (
              <div key={premise.id} className="grid grid-cols-2 gap-x-4 items-center p-2 border-b border-slate-200">
                <p className="text-slate-700">{premise.text}</p>
                <select
                  value={(currentAnswer.value as { [key: string]: string })?.[premise.id] || ''}
                  onChange={(e) => handleMatchingAnswerChange(currentQuestion.id, premise.id, e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="">Select match...</option>
                  {responses.map(response => (
                    <option key={response.id} value={response.text}>{response.text}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        );
      case QuestionType.FillInTheBlank:
        const questionParts = currentQuestion.text.split('___');
        const numBlanks = questionParts.length - 1;
        return (
            <div>
                <p className="mb-2 text-slate-700 whitespace-pre-wrap">
                    {questionParts.map((part, index) => (
                        <React.Fragment key={index}>
                            {part}
                            {index < numBlanks && <span className="font-bold text-primary-600 text-lg"> ___ </span>}
                        </React.Fragment>
                    ))}
                </p>
                {numBlanks > 0 && (
                    <div className="space-y-3 mt-4">
                    {Array(numBlanks).fill(null).map((_, blankIdx) => (
                        <div key={blankIdx} className="flex items-center">
                            <label className="mr-2 text-sm text-slate-600">Blank {blankIdx + 1}:</label>
                            <input
                                type="text"
                                value={((currentAnswer.value as string[]) || [])[blankIdx] || ''}
                                onChange={(e) => handleFillInBlankAnswerChange(currentQuestion.id, blankIdx, e.target.value)}
                                className="flex-grow p-2 border border-slate-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                            />
                        </div>
                    ))}
                    </div>
                )}
            </div>
        );

      default:
        return <p>Unsupported question type.</p>;
    }
  };
  
  const totalQuestions = quiz.questions.length;

  return (
    <div className="max-w-3xl mx-auto">
      <Card>
        <div className="p-6 border-b border-slate-200">
          <h1 className="text-2xl font-bold text-slate-800">{quiz.title}</h1>
          {quiz.instructions && <p className="text-sm text-slate-600 mt-1">{quiz.instructions}</p>}
          <div className="mt-3 flex justify-between items-center text-sm">
            <p className="text-slate-500">Question {currentQuestionIndex + 1} of {totalQuestions}</p>
            {timeLeft !== null && (
              <p className={`font-semibold flex items-center ${timeLeft < 60 ? 'text-red-500' : 'text-primary-600'}`}>
                <ClockIcon/> Time Left: {formatTime(timeLeft)}
              </p>
            )}
          </div>
        </div>

        {currentQuestion && (
          <div className="p-6">
            <h2 className="text-lg font-semibold text-slate-700 mb-1">{currentQuestion.text}</h2>
            <p className="text-xs text-slate-500 mb-4">({currentQuestion.points} points)</p>
            {renderQuestionContent()}
          </div>
        )}
        
        <div className="p-6 border-t border-slate-200 flex justify-between items-center">
          <Button
            onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
            disabled={currentQuestionIndex === 0 || isSubmitting}
            variant="secondary"
          >
            Previous
          </Button>
          {currentQuestionIndex < totalQuestions - 1 ? (
            <Button
              onClick={() => setCurrentQuestionIndex(prev => Math.min(totalQuestions - 1, prev + 1))}
              disabled={isSubmitting}
              variant="primary"
            >
              Next
            </Button>
          ) : (
            <Button
              onClick={() => setShowConfirmModal(true)}
              disabled={isSubmitting}
              variant="success"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Quiz'}
            </Button>
          )}
        </div>
      </Card>

      <Modal
        isOpen={showConfirmModal}
        onClose={() => setShowConfirmModal(false)}
        title="Confirm Submission"
        footer={
          <>
            <Button variant="secondary" onClick={() => setShowConfirmModal(false)}>Cancel</Button>
            <Button variant="success" onClick={() => handleSubmitQuiz(false)} isLoading={isSubmitting}>
              {isSubmitting ? 'Submitting...' : 'Yes, Submit Now'}
            </Button>
          </>
        }
      >
        <p>Are you sure you want to submit your answers? You cannot make changes after submission.</p>
        <p className="mt-2 text-sm text-slate-500">
          {answers.filter(a => a.value !== getDefaultAnswerValue(a.questionType) && (Array.isArray(a.value) ? a.value.length > 0 : true)).length} of {totalQuestions} questions answered.
        </p>
      </Modal>
    </div>
  );
};

export default TakeQuizPage;
